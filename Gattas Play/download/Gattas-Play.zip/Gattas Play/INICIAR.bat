@echo off
cd /d "%~dp0"
if not exist launcher\config.json copy launcher\config.example.json launcher\config.json
echo Abrindo Gattas Play em http://127.0.0.1:5173
echo Coloque ROMs em roms\snes , roms\ps2 , etc.
python launcher\server.py
pause
