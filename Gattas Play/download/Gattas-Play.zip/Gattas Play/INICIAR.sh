#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -f launcher/config.json ] || cp launcher/config.example.json launcher/config.json
echo "Abrindo Gattas Play em http://127.0.0.1:5173"
python3 launcher/server.py
